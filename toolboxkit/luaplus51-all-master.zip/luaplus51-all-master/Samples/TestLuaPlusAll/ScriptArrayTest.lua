TestArray =
{
	"String 1",
	5,
	"String 2",
	"String 3",
	[1000] = 10.0,
}


