Number = 5

PrintNumber(Number)
PrintNumber(Add(1, 2))

