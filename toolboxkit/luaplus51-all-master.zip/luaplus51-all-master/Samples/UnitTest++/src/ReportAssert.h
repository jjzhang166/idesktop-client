#ifndef UNITTEST_ASSERT_H
#define UNITTEST_ASSERT_H

namespace UnitTest {

void ReportAssert(char const* description, char const* filename, int lineNumber);
    
}

#endif
