require_ 'dollar'
print($PATH)
if $(ls) ~= 0 then
  $(dir /B) -- so there!
end


