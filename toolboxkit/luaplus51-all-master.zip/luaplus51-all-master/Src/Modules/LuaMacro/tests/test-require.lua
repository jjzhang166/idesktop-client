require_ 'mmath'

print(sin(1.2) + cos(0.3))
