require_ 'qw'

print(qw(one two three))
