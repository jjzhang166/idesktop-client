// ManagedLuaPlus.h

#pragma once

using namespace System;

