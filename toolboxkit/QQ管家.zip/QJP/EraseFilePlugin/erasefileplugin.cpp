#include "erasefileplugin.h"

EraseFilePlugin::EraseFilePlugin()
{

}

EraseFilePlugin::~EraseFilePlugin()
{

}
