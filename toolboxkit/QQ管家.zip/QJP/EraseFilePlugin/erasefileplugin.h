#ifndef ERASEFILEPLUGIN_H
#define ERASEFILEPLUGIN_H

#include "erasefileplugin_global.h"

class ERASEFILEPLUGIN_EXPORT EraseFilePlugin
{
public:
    EraseFilePlugin();
    ~EraseFilePlugin();

private:

};

#endif // ERASEFILEPLUGIN_H
