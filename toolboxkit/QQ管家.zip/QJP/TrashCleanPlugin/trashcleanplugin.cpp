#include "trashcleanplugin.h"

TrashCleanPlugin::TrashCleanPlugin()
{

}

TrashCleanPlugin::~TrashCleanPlugin()
{

}
