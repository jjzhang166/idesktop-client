#ifndef TRASHCLEANPLUGIN_H
#define TRASHCLEANPLUGIN_H

#include "trashcleanplugin_global.h"

class TRASHCLEANPLUGIN_EXPORT TrashCleanPlugin
{
public:
    TrashCleanPlugin();
    ~TrashCleanPlugin();

private:

};

#endif // TRASHCLEANPLUGIN_H
