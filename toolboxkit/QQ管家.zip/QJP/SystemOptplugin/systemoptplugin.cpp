#include "systemoptplugin.h"

SystemOptplugin::SystemOptplugin()
{

}

SystemOptplugin::~SystemOptplugin()
{

}
