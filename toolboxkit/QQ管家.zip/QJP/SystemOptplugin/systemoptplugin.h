#ifndef SYSTEMOPTPLUGIN_H
#define SYSTEMOPTPLUGIN_H

#include "systemoptplugin_global.h"

class SYSTEMOPTPLUGIN_EXPORT SystemOptplugin
{
public:
    SystemOptplugin();
    ~SystemOptplugin();

private:

};

#endif // SYSTEMOPTPLUGIN_H
