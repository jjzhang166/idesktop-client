//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by clstencil.rc
//
#define IDS_HEADER                      101
#define IDS_NOTSUPPORTED                102
#define IDS_USAGE                       103
#define IDS_ERROR                       104
#define IDS_UNKNOWN_PARAM               105
#define IDS_INPUT_FILE                  106
#define IDS_INVALID_ARGS                107
#define IDS_INIT_FAILED                 108
#define IDS_SERVER_VARIABLE_NOT_FOUND   109
#define IDS_QS_TOO_LONG                 110
#define IDS_CONTENT_TYPE_TOO_LONG       111
#define IDS_CT_TOO_LONG                 111
#define IDS_VERB_TOO_LONG               112

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        109
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1000
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
