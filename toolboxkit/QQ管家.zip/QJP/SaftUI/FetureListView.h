#pragma once
#include <QListView>
class CFetureListView :public QListView
{  
	Q_OBJECT
public:
	CFetureListView(QWidget *parent = 0);
	~CFetureListView(void);
};
