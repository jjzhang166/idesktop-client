#pragma once
#include <QWidget>
class ConectLeft :public QWidget
{
public:
  ConectLeft(QWidget *parent = 0, Qt::WFlags flags = 0);
  ~ConectLeft(void);
};
