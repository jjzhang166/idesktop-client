#pragma once
#include <QWidget>
class ConectRightWidth :public QWidget
{
public:
  ConectRightWidth(QWidget *parent = 0, Qt::WFlags flags = 0);
  ~ConectRightWidth(void);
};
