#include "StatuBar.h"

StatuBar::StatuBar(QWidget *parent , Qt::WFlags flags)
:QWidget(parent,flags)
{
}

StatuBar::~StatuBar(void)
{
}
