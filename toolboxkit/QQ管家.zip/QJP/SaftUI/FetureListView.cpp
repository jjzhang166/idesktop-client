#include "FetureListView.h"

CFetureListView::CFetureListView(QWidget *parent)
:QListView(parent)
{
	//http://www.cnblogs.com/appsucc/archive/2012/02/28/2371506.html
}

CFetureListView::~CFetureListView(void)
{
}
