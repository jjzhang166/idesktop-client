#include "ConectRightWidth.h"

ConectRightWidth::ConectRightWidth(QWidget *parent, Qt::WFlags flags)
:QWidget(parent,flags)
{
}

ConectRightWidth::~ConectRightWidth(void)
{
}
