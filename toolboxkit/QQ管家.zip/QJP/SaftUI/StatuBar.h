#pragma once
#include <QWidget>
class StatuBar: public QWidget
{
public:
  StatuBar(QWidget *parent = 0, Qt::WFlags flags = 0);
  ~StatuBar(void);
};
